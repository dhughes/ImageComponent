The Examples folder contains 7 examples of using the Alagad Image Component.  
You should extract the examples folder into a directory in your website.  Create
a ColdFusion mapping "/Image" pointing to the directory where you extracted the
Alagad Image Component.  

You can reset the examples by running the reset.cfm file.
