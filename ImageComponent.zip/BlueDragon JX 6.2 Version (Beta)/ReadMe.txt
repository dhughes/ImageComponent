Alagad Image Component Beta for BlueDragon 6.2 (and later)
ReadMe Notes

http://www.alagad.com/index.cfm/name-aic/cd-1

==========================================================================
Table of Contents
This read me file contains the following information.

  Known Issues with the Beta

Known Issues with the Beta
====================

The following methods are know to not function correctly with the beta version
of the Alagad Image Component for BlueDragon.

  adjustLevels()
  darken()
  lighten()
  negate()
  
  Use of the following items cause drawString() not to work.

  setStringSize()
  setStringStrikeThrough()
  setStringUnderline()
  setStringPosture()
  setStringWeight()
  setStringWidth()
  
  The getSimpleStringMetrics() only returns the width and height of a string.

To download the latest version vist http://www.alagad.com

=======================================================================

Copyright (c) 2004 Alagad Inc. All rights reserved. 

=======================================================================